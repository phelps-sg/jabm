InfoNode Docking Windows
========================

InfoNode Docking Windows is developed by NNL Technology AB. Visit
<http://www.infonode.net> for more information and the latest version
of the library.

This distribution contains the following products:

 - InfoNode Docking Windows
 - InfoNode Tabbed Panel
 - InfoNode Look and Feel

See the README files for the individual products for more information. 
This distribution contains the following files:

- /lib                  : contains the library jar file
- /docs                 : contains the Javadoc documentation
- /examples             : source code examples
- LICENSE.txt           : the license for the products
- RELEASE_NOTES_*.txt   : the release notes for the products
- README                : this file
- README_*.txt          : the README files for the products


Copyright (c) 2004 - 2009 NNL Technology AB, www.nnl.se
