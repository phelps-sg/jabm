package net.sourceforge.jabm.report;

public interface WeightedEdge {

	public double getValue();
	
}
